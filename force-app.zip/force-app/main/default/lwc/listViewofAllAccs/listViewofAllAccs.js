import { LightningElement, wire } from 'lwc';
import accList from '@salesforce/apex/listViewOFAllAccsController.listOfAllAccs';


export default class ListViewofAllAccs extends LightningElement {
    data;
    rowoffset = 0;
    @wire(accList)
    listOfAcc
    columns = [
        { label: 'Name', fieldName: 'Name', editable: true },
        { label: 'Phone', fieldName: 'Phone', editable: true }
    ];
}
