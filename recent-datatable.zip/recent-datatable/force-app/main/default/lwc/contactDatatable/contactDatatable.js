import { LightningElement,wire} from 'lwc';
import result from '@salesforce/apex/contactDatatableController.getList';
export default class ContactDatatable extends LightningElement {
    @wire(result, {option:'$apple'})
    getAll;
    apple;
      
  cols = [
          { label: 'Last Name', fieldName: 'LastName', editable: true, sortable: true},
          { label: 'Account Name', fieldName: 'Account.Name', editable: true, sortable: true},
          { label: 'Phone', fieldName: 'Phone', type: 'Phone', editable: true, sortable: true },
          { label: 'Email Address', fieldName: 'Email', type: 'email', editable: true, sortable: true},
          { label: 'Level', fieldName: 'Level__c', type: 'Picklist', editable: true, sortable: true }
        
      ]; 
      
   selectedVal;
  
      get options() {
          return [
              { label: 'Primary', value: 'Primary' },
              { label: 'Secondary', value: 'Secondary' },
              { label: 'Tertiary', value: 'Tertiary' },
          ];
      }
     
      handleChange(event) {
          this.selectedVal = event.detail.value;
          
      }
      handleClick(){
       
           this.apple=this.selectedVal;   
             }
}