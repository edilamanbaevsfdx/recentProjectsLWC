import { LightningElement, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getContacts from "@salesforce/apex/mapController.getContacts";

const PAGE_SIZE = 10;

export default class Map extends LightningElement {
location = [];
currentPage = 1;
totalPages = 0;

@wire(getContacts)
contacts({ data, error }) {
    if (data) {
        let contacts = data.filter(c => c.MailingCity !== null);
        this.totalPages = Math.ceil(contacts.length / PAGE_SIZE);
        let startIndex = (this.currentPage - 1) * PAGE_SIZE;
        let endIndex = startIndex + PAGE_SIZE;
        contacts = contacts.slice(startIndex, endIndex);
        contacts.forEach((n) => {
            let icon = "standard:account";
            if (n.Industry === 'Finance') {
                icon = "custom:custom1";
            } else if (n.Industry === 'Healthcare') {
                icon = "custom:custom2";
            }
            // Add custom logic to determine the icon based on contact properties
            this.location = [...this.location,
                {
                    location: {
                        City: n.MailingCity,
                        Country: n.MailingCountry
                    },
                    icon: icon,
                    title: n.LastName + ', ' + n.FirstName,
                    description: n.Title
                }
            ];
        });
    } else if (error) {
        this.showToast('Error', 'Error occurred while fetching contacts: ' + error.body.message, 'error');
    }
}

handleMarkerSelect(event) {
    // Add custom logic to handle marker selection, such as displaying contact details or navigating to the contact record
}

handleFirstPage() {
    this.currentPage = 1;
    this.location = [];
    this.contacts();
}

handlePreviousPage() {
    this.currentPage--;
    this.location = [];
    this.contacts();
}

handleNextPage() {
    this.currentPage++;
    this.location = [];
    this.contacts();
}

handleLastPage() {
    this.currentPage = this.totalPages;
    this.location = [];
    this.contacts();
}

showToast(title, message, variant) {
    const event = new ShowToastEvent({
        title: title,
        message: message,
        variant: variant
    });
    this.dispatchEvent(event);
}
}